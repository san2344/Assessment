package base;

import java.io.IOException;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterMethod;
import org.testng.annotations.BeforeMethod;
import org.testng.annotations.DataProvider;

import Utils.ReadExcel;

public class projectspecificMethod {
	public WebDriver driver;
	public String excelFileName;

	@BeforeMethod
	public void PreCodition() {
		System.setProperty("webdriver.chrome.driver","C:\\Users\\user\\Downloads\\chromedriver.exe");
		driver = new ChromeDriver();
		driver.get("https://www.flipkart.com/");
		driver.manage().window().maximize();
		driver.manage().timeouts().implicitlyWait(5, TimeUnit.SECONDS);
			   
		}
	 
	 @AfterMethod
	 public void postCondition() {
		 driver.close();
		
}
	 
	 @DataProvider(name="fetchData", indices=0) // only use read data from excel
	 public String[][] sentData() throws IOException{ 
		  return ReadExcel.readData(excelFileName); 
		 }
}