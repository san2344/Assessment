package week4;

import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

import base.projectspecificMethod;

public class flipkartlogin extends projectspecificMethod {
	
	@BeforeTest 
	  public void setFileName() {   
		  excelFileName = "flipkart";
		  }

	@Test(dataProvider="fetchData")
	public void runflipkart(String username, String password) throws InterruptedException{
		CloseloginPage as = new CloseloginPage();
		as.CloginPage().
		Clicklogin().
		enterUsername(username).
		enterpassword(password).
		clicksubmit();
		
			}

	
}
