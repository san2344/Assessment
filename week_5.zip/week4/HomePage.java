package week4;

import org.openqa.selenium.By;

import base.projectspecificMethod;

public class HomePage extends projectspecificMethod {
	
	public HomePage Clicklogin(){
		driver.findElement(By.className("_1_3w1N")).click();
		return this;
		
	}
	public HomePage enterUsername(String uName){
		driver.findElement(By.className("_2IX_2- VJZDxU")).sendKeys(uName);
		return this;
		
	}
	public HomePage enterpassword(String Psw){
		driver.findElement(By.className("_2IX_2- _3mctLh VJZDxU")).sendKeys(Psw);
		return this;
		
	}
	public HomePage clicksubmit(){
		driver.findElement(By.className("_2KpZ6l _2HKlqd _3AWRsL")).click();
		return this;
		
	}
}
