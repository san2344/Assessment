package week4;

import org.openqa.selenium.By;

import base.projectspecificMethod;
import week4.HomePage;

public class CloseloginPage extends projectspecificMethod{

	public HomePage CloginPage(){
		driver.findElement(By.xpath("/html/body/div[2]/div/div/button")).click();
		return new HomePage();
	}
}
